from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_admin
from app.models.user import User


router = APIRouter(
    prefix="/admin",
    tags=["Admin"],
    # Require admin login for every endpoint in this router
    dependencies=[Depends(get_current_admin)],
)


@router.get("/health")
def admin_health(admin: User = Depends(get_current_admin)):
    return {"ok": True, "admin_id": admin.id}


@router.get("/users")
def list_users(db: Session = Depends(get_db), admin: User = Depends(get_current_admin)):
    return db.query(User).order_by(User.id.desc()).all()


@router.post("/users/{user_id}/toggle-active")
def toggle_user_active(user_id: int, db: Session = Depends(get_db), admin: User = Depends(get_current_admin)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_active = not bool(user.is_active)
    db.add(user)
    db.commit()
    return {"id": user.id, "is_active": user.is_active}
